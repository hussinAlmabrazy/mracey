# 🚀 دليل نشر منصة مراسي — Vercel + Turso (مجاني تماماً)

هذا الدليل يشرح خطوة بخطوة كيفية رفع منصة مراسي إلى الإنترنت بمعمارية سحابية مجانية بدون بطاقة ائتمانية.

## 🏗️ المعمارية

| المكوّن | الخدمة | الخطة | الدور |
|---|---|---|---|
| استضافة التطبيق | [Vercel](https://vercel.com) | Hobby (مجانية) | تشغيل Next.js + Server Actions |
| قاعدة البيانات | [Turso](https://turso.tech) | Free (مجانية) | SQLite سحابية دائمة لا تُمسح مع النشر |

**لماذا Turso؟** نظام ملفات Vercel مؤقت — أي ملف SQLite محلي يُحذف مع كل نشر. Turso قاعدة بيانات SQLite سحابية (نفس التقنية التي يعمل بها مشروعك الآن) فلا يتغير أي شيء في منطق التطبيق، وقد ضُبط المشروع مسبقاً للعمل عليها تلقائياً عند إضافة متغيري `TURSO_DATABASE_URL` و `TURSO_AUTH_TOKEN`.

---

## 📋 قبل البدء — ما تحتاجه

1. **حساب GitHub** (مجاني) — [github.com/signup](https://github.com/signup)
2. **حساب Vercel** — سجّل بحساب GitHub نفسه: [vercel.com](https://vercel.com)
3. **جهاز فيه Node.js 20+** لتنفيذ أوامر Turso CLI — أو استخدم GitHub Codespaces مجاناً
4. ملف الحزمة `marsaa-platform-deploy.zip` (يحتوي كل شيء)

---

## الخطوة 1️⃣: رفع الكود إلى GitHub

1. فك ضغط `marsaa-platform-deploy.zip` في مجلد، مثلاً `marsaa`
2. أنشئ مستودعاً **خاصاً (Private)** جديداً على [github.com/new](https://github.com/new) باسم `marsaa-platform`
3. من داخل مجلد المشروع نفّذ:

```bash
cd marsaa
git init
git add .
git commit -m "منصة مراسي — جاهزة للنشر"
git branch -M main
git remote add origin https://github.com/USERNAME/marsaa-platform.git
git push -u origin main
```

> 🔒 ملف `.env` وقاعدة البيانات `db/` مستثنيان تلقائياً عبر `.gitignore` — لن يُرفعا إلى GitHub أبداً.

---

## الخطوة 2️⃣: إنشاء قاعدة Turso بنفس بياناتك الحالية

كل بياناتك الحالية (المكاتب، المستخدمون، الخدمات، الطلبات، العملاء) ستنتقل كما هي.

### 2-أ) تثبيت Turso CLI

```bash
# macOS / Linux
curl -sSfL https://get.tur.so/install.sh | bash

# Windows (PowerShell)
irm https://get.tur.so/install.ps1 | iex
```

### 2-ب) تسجيل الدخول

```bash
turso auth signup
```
(سجل بحساب GitHub — بدون بطاقة ائتمانية)

### 2-ج) إنشاء القاعدة من ملفك الحالي ⭐

```bash
cd marsaa
turso db create marasa --from-file db/custom.db --wait
```

هذا الأمر ينشئ قاعدة بيانات سحابية **تحتوي كل بياناتك الحالية** (المخطط + البيانات).

> **البديل** إن فشل الأمر لأي سبب:
> ```bash
> turso db create marasa --wait
> turso db shell marasa < db/dump.sql
> ```

### 2-د) احصل على الرابط والتوكن (ستحتاجهما في الخطوة 3)

```bash
# رابط القاعدة — انسخه (يبدأ بـ libsql://)
turso db show marasa --url

# توكن الوصول — انسخه (نص طويل يبدأ بـ eyJ)
turso db tokens create marasa
```

---

## الخطوة 3️⃣: النشر على Vercel

1. اذهب إلى [vercel.com/new](https://vercel.com/new)
2. اربط حساب GitHub واختر مستودع `marsaa-platform` ثم **Import**
3. **قبل الضغط على Deploy** — افتح قسم **Environment Variables** وأضف الثلاثة التالية:

| الاسم | القيمة |
|---|---|
| `TURSO_DATABASE_URL` | رابط القاعدة من الخطوة 2-د (مثل `libsql://marasa-xxxx.turso.io`) |
| `TURSO_AUTH_TOKEN` | التوكن من الخطوة 2-د |
| `AUTH_SECRET` | مفتاح جلسات قوي — ولّده بالأمر التالي والصق ناتجه |

```bash
# ولّد مفتاح AUTH_SECRET عشوائياً قوياً
openssl rand -base64 32
```

> ⚠️ **مهم جداً**: لا تترك `AUTH_SECRET` فارغاً — يوجد مفتاح احتياطي افتراضي معروف في الكود، وعدم ضبط قيمة خاصة بك يعني أن أي شخص يعرف المفتاح الافتراضي يستطيع انتحال الجلسات.

4. اضغط **Deploy** وانتظر ~3 دقائق
5. ستحصل على الرابط: `https://marsaa-platform.vercel.app` 🎉

---

## الخطوة 4️⃣: التحقق والأمان

1. افتح `https://your-project.vercel.app/admin/login`
2. سجّل الدخول ببياناتك الحالية نفسها (انتقلت مع القاعدة):
   - `admin@marsaa.ye` / `Admin@2026`
3. **غيّر كلمة المرور والبريد فوراً** من: الإعدادات العامة → إعدادات الحساب (الميزة المضافة مؤخراً)
4. جرّب أيضاً دخول المكاتب ودخول العملاء للتأكد

---

## 📊 حدود الخطة المجانية

| | الحد المجاني | وضع منصتك |
|---|---|---|
| **Vercel Hobby** | 100GB باندويث شهرياً | كافٍ جداً لعدة مكاتب |
| **Turso Free** | 100 قاعدة بيانات، 5GB تخزين، 500 مليون قراءة صف/شهر، 10 مليون كتابة صف/شهر | قاعدة الحالية ~0.5MB فقط |
| الاستجابة الباردة | أول زائر بعد خمول قد ينتظر 1-2 ثانية | طبيعي في الخطة المجانية |

> 📌 خطة Vercel Hobby مخصصة رسمياً للاستخدام الشخصي غير التجاري. مثالية لمرحلة التجربة والتسويق لأول عملائك. عند بدء التشغيل التجاري الفعلي: اشترك بخطة Pro (~20$/شهر).

---

## ⚠️ قيد مهم: الملفات المرفوعة (مستندات الطلبات)

نظام ملفات Vercel **مؤقت**: المستندات التي يرفعها العملاء مع طلباتهم (PDF/صور) **لا تبقى بعد كل عملية نشر جديدة**.

- ✅ يعمل حالياً بشكل كامل: الطلبات وحالاتها، التعليقات، المحادثة، الفواتير، المدفوعات، الإشعارات، التقارير
- ⚠️ يحتاج حلاً سحابياً: مرفقات المستندات الفعلية (تخزين Vercel Blob أو Cloudflare R2)

اطلب من مساعدك إضافة "تخزين المرفقات على Vercel Blob" كمهمة تالية عند الحاجة — تعديل محصور في `src/lib/files.ts` فقط.

---

## 🔧 استكشاف الأخطاء

| المشكلة | الحل |
|---|---|
| خطأ 500 عند الدخول | تأكد من `TURSO_DATABASE_URL` و `TURSO_AUTH_TOKEN` في Vercel → Settings → Environment Variables ثم أعد النشر (Redeploy) |
| "عدم تطابق البيانات" أو بيانات ناقصة | تأكد أنك نفذت `turso db create --from-file` من مجلد المشروع الذي يحتوي `db/custom.db` |
| نسيت `AUTH_SECRET` | أضفه لاحقاً من الإعدادات ثم Redeploy — الجلسات القديمة ستُطلب تسجيلها من جديد فقط |
| أردت تحديث قاعدة البيانات بالكامل لاحقاً | `turso db destroy marasa` ثم أعد الخطوة 2-ج |

## 🔄 تحديث المنصة لاحقاً

بعد أي تعديل على الكود (من مساعدك هنا):

```bash
git add .
git commit -m "وصف التعديل"
git push
```

Vercel ينشر التعديل تلقائياً خلال ~دقيقة — قاعدة البيانات لا تتأثر.

## 💾 نسخة احتياطية دورية من قاعدة البيانات

```bash
# تفريغ كامل (مخطط + بيانات) إلى db/dump.sql
bun scripts/db-dump.ts

# أو من Turso مباشرة
turso db shell marasa ".dump" > backup.sql
```

---

## 🗺️ خلاصة سريعة (للمختصرين)

```
GitHub (رفع الكود) → turso db create marasa --from-file db/custom.db
→ Vercel: New Project → Import → أضف TURSO_DATABASE_URL + TURSO_AUTH_TOKEN + AUTH_SECRET
→ Deploy → سجّل ببياناتك → غيّر كلمة المرور فوراً
```
