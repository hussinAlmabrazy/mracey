// فحص/تحديث سريع لحساب مدير المنصة من سطر الأوامر
// الاستخدام: bun scripts/check-admin.ts [email] [password]
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

async function main() {
  const admin = await db.user.findFirst({ where: { role: "SUPER_ADMIN" } });
  if (!admin) { console.log("NO SUPER_ADMIN FOUND"); return; }

  if (process.argv[2] && process.argv[3]) {
    // وضع التحديث: استعادة البريد/كلمة المرور الأصلية
    await db.user.update({
      where: { id: admin.id },
      data: { email: process.argv[2], passwordHash: await bcrypt.hash(process.argv[3], 10) },
    });
    console.log(`RESTORED -> email=${process.argv[2]} password=***`);
  }

  const fresh = await db.user.findUnique({ where: { id: admin.id } });
  console.log(`id=${fresh.id}`);
  console.log(`email=${fresh.email}`);
  console.log(`name=${fresh.name}`);
  console.log(`hashPrefix=${fresh.passwordHash.slice(0, 7)}`);
  if (process.argv[3]) {
    const ok = await bcrypt.compare(process.argv[3], fresh.passwordHash);
    console.log(`passwordCheck(${process.argv[3]})=${ok ? "MATCH" : "NO-MATCH"}`);
  }
}

main().finally(() => db.$disconnect());
