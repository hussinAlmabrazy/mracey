#!/usr/bin/env python3
"""
ديمون تشغيل خادم التطوير بأسلوب double-fork daemonization.
السبب: بيئة沙 البنية تقتل شجرة عمليات جلسة الأوامر عند انتهائها،
والـ double-fork (fork → setsid → fork → orphan to PID 1) يفلت من هذا التنظيف.
الاستخدام: python3 scripts/dev-daemon.py [start|status|stop]
"""
import os
import sys
import time
import signal
import urllib.request

PID_FILE = "/tmp/next-dev-daemon.pid"
CWD = "/home/z/my-project"
LOG_FILE = os.path.join(CWD, "dev.log")


def is_alive(pid):
    try:
        os.kill(pid, 0)
        # تأكد أنه عملية next فعلية وليست PID معاد استخدامها
        with open(f"/proc/{pid}/cmdline", "rb") as f:
            cmd = f.read().decode(errors="ignore")
        return "next" in cmd or "bun" in cmd or "node" in cmd
    except (ProcessLookupError, PermissionError, FileNotFoundError, OSError):
        return False


def port_open():
    try:
        with urllib.request.urlopen("http://127.0.0.1:3000/", timeout=4) as r:
            return r.status == 200
    except Exception:
        return False


def daemon_start():
    # التحقق أولاً من المنفذ بدل PID فقط (قد يكون الخادم حياً بـ PID مختلف)
    if port_open():
        print("ALREADY_RUNNING: server responds on port 3000")
        return
    pid = 0
    if os.path.exists(PID_FILE):
        try:
            pid = int(open(PID_FILE).read().strip())
        except Exception:
            pid = 0
        if pid and is_alive(pid):
            print(f"ALREADY_RUNNING: pid={pid} (but port closed — killing stale daemon)")
            try:
                os.kill(pid, signal.SIGKILL)
            except OSError:
                pass
            time.sleep(1)

    # fork أول
    pid1 = os.fork()
    if pid1 > 0:
        # الأب الأول: ينتظر حتى يستجيب المنفذ ثم يخرج بالنتيجة
        for _ in range(90):  # حتى 45 ثانية
            time.sleep(0.5)
            if port_open():
                print("STARTED_OK: dev server is up on port 3000")
                return
        print("START_TIMEOUT: server did not respond within 45s — راجع dev.log")
        sys.exit(1)

    # الابن الأول
    os.setsid()
    pid2 = os.fork()
    if pid2 > 0:
        os._exit(0)  # الأب الثاني يخرج → الابن يُبتر ويتبنى للـ PID 1

    # الابن النهائي (ديمون حقيقي)
    os.chdir(CWD)
    devnull = os.open(os.devnull, os.O_RDWR)
    os.dup2(devnull, 0)
    os.dup2(devnull, 1)
    os.dup2(devnull, 2)

    # اكتب PID قبل التنفيذ
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))

    # شغّل خادم التطوير عبر bun مع تسجيل المخرجات في dev.log
    # (بدل خط أنابيب tee — أعد التوجيه مباشرة للملف)
    os.execvp("bash", ["bash", "-c",
        'exec bun run dev-local >> dev.log 2>&1' if False else
        'exec bun x next dev -p 3000 >> dev.log 2>&1'])


def daemon_status():
    if port_open():
        pid = 0
        if os.path.exists(PID_FILE):
            try:
                pid = int(open(PID_FILE).read().strip())
            except Exception:
                pass
        print(f"RUNNING: port 3000 OK (daemon pid={pid or '?'})")
        return
    print("STOPPED: port 3000 closed")


def daemon_stop():
    pid = 0
    if os.path.exists(PID_FILE):
        try:
            pid = int(open(PID_FILE).read().strip())
        except Exception:
            pid = 0
    # اقتل شجرة next كاملة (next-server و bun و node)
    os.system("pkill -f 'next dev' 2>/dev/null; pkill -f 'next-server' 2>/dev/null; "
              "pkill -f 'bun x next' 2>/dev/null; pkill -f 'bun run dev' 2>/dev/null")
    if pid:
        try:
            os.kill(pid, signal.SIGKILL)
        except OSError:
            pass
    if os.path.exists(PID_FILE):
        os.remove(PID_FILE)
    print("STOPPED")


if __name__ == "__main__":
    action = sys.argv[1] if len(sys.argv) > 1 else "start"
    {"start": daemon_start, "status": daemon_status, "stop": daemon_stop}[action]()
