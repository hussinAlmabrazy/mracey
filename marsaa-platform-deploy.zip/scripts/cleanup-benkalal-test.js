/* eslint-disable @typescript-eslint/no-require-imports */
// تنظيف بيانات الاختبار لمكتب بن خليل: الطلب التجريبي + العميل التجريبي (مع الإبقاء على الخدمات)
const { PrismaClient } = require("@prisma/client");
const p = new PrismaClient();

async function main() {
  const reqId = "cmvo9un3q0043rix3wsl3qgfj";
  const customerId = "cmvo9qh7b0041rix3vnth1tgq";

  const req = await p.request.findUnique({ where: { id: reqId } });
  if (!req) { console.log("الطلب غير موجود — ربما نُظّف مسبقاً"); }
  else {
    // المرفقات على القرص
    const docs = await p.requestDocument.findMany({ where: { requestId: reqId } });
    console.log(`مستندات الطلب: ${docs.length}`);
    // حذف التبعات
    await p.requestStatusHistory.deleteMany({ where: { requestId: reqId } });
    await p.requestDocument.deleteMany({ where: { requestId: reqId } });
    await p.comment.deleteMany({ where: { requestId: reqId } });
    await p.task.deleteMany({ where: { requestId: reqId } });
    await p.notification.deleteMany({ where: { requestId: reqId } });
    await p.messageLog.deleteMany({ where: { requestId: reqId } });
    await p.request.delete({ where: { id: reqId } });
    console.log(`حُذف الطلب ${req.requestNumber} وتوابعه`);
    // سجلات التدقيق المتعلقة
    await p.auditLog.deleteMany({ where: { entityId: reqId } });
  }

  const cust = await p.customer.findUnique({ where: { id: customerId } });
  if (cust) {
    await p.notification.deleteMany({ where: { customerId } });
    await p.customer.delete({ where: { id: customerId } });
    console.log(`حُذف العميل: ${cust.name}`);
    await p.auditLog.deleteMany({ where: { entityId: customerId } });
  } else console.log("العميل غير موجود");

  // التحقق النهائي
  const office = await p.office.findFirst({
    where: { slug: "benkalal-com" },
    select: { name: true, _count: { select: { services: true, customers: true, users: true, requests: true } } },
  });
  console.log("وضع المكتب النهائي:", JSON.stringify(office, null, 2));
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(() => p.$disconnect());
