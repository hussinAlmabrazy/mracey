/* eslint-disable @typescript-eslint/no-require-imports */ // سكربت تحقق واحد الإصدار — يستخدم require
// تنظيف بيانات اختبار E2E: الطلب BENK-2026-0001 والعميل التجريبي
// (الخدمة "نقل بري وتوصيل المطار" تبقى كنموذج حقيقي قابل للتعديل)
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();

async function main() {
  const office = await db.office.findFirst({ where: { slug: "benkalal-com" }, select: { id: true } });
  if (!office) return console.log("المكتب غير موجود");
  const officeId = office.id;

  // الطلبات التجريبية لهذا المكتب
  const testRequests = await db.request.findMany({
    where: { officeId, requestNumber: { startsWith: "BENK-" } },
    select: { id: true, requestNumber: true },
  });
  console.log(`طلبات الاختبار: ${testRequests.map((r) => r.requestNumber).join(", ") || "لا شيء"}`);

  for (const req of testRequests) {
    // التبعيات
    await db.requestDocument.deleteMany({ where: { requestId: req.id } });
    await db.requestStatusHistory.deleteMany({ where: { requestId: req.id } });
    await db.notification.deleteMany({ where: { requestId: req.id } });
    await db.comment.deleteMany({ where: { requestId: req.id } });
    await db.task.deleteMany({ where: { requestId: req.id } });
    await db.auditLog.deleteMany({ where: { entityId: req.id } });
    await db.request.delete({ where: { id: req.id } });
    console.log(`- حُذف الطلب ${req.requestNumber} وتوابعه`);
  }

  // العميل التجريبي
  const delCustomers = await db.customer.deleteMany({
    where: { officeId, phone: "777123456" },
  });
  console.log(`- حُذف العملاء التجريبيون: ${delCustomers.count}`);

  // إعادة ضبط عداد الطلبات
  await db.office.update({ where: { id: officeId }, data: { reqCounter: 0, storageUsedMb: 0 } });
  console.log("- أُعيد ضبط reqCounter=0 و storageUsedMb=0");

  // التحقق النهائي
  const [svcCount, custCount, reqCount] = await Promise.all([
    db.service.count({ where: { officeId } }),
    db.customer.count({ where: { officeId } }),
    db.request.count({ where: { officeId } }),
  ]);
  console.log(`\nالوضع النهائي لمكتب بن خليل: ${svcCount} خدمة · ${custCount} عميل · ${reqCount} طلب`);
  const services = await db.service.findMany({ where: { officeId }, select: { name: true, isActive: true } });
  for (const s of services) console.log(`  - ${s.name} ${s.isActive ? "(نشطة)" : "(معطلة)"}`);
}

main().catch(console.error).finally(() => db.$disconnect());
