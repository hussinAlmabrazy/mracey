// ============================================================
// اختبار استعادة: تطبيق db/dump.sql على قاعدة جديدة ثم
// مقارنة عدد صفوف كل جدول مع القاعدة الأصلية
// ============================================================
import { createClient } from '@libsql/client'
import { unlinkSync, existsSync } from 'fs'

const SOURCE = 'file:/home/z/my-project/db/custom.db'
const RESTORE = 'file:/home/z/my-project/db/restore-test.db'
const DUMP = '/home/z/my-project/db/dump.sql'

/** تقسيم SQL مع مراعاة النصوص المقتبسة و X'hex' */
function splitSql(sql: string): string[] {
  const stmts: string[] = []
  let cur = ''
  let inStr = false
  for (let i = 0; i < sql.length; i++) {
    const ch = sql[i]
    cur += ch
    if (ch === "'") {
      // '' تهريب داخل النص، وإلا فتح/إغلاق
      if (inStr && sql[i + 1] === "'") {
        cur += "'"
        i++
      } else {
        inStr = !inStr
      }
    } else if (ch === ';' && !inStr) {
      const t = cur.trim()
      if (t && t !== ';') stmts.push(t)
      cur = ''
    }
  }
  const tail = cur.trim()
  if (tail) stmts.push(tail)
  return stmts
}

async function main() {
  const dump = await Bun.write === undefined ? '' : '' // noop للاستراحة
  const sql = await Bun.file(DUMP).text()

  if (existsSync('/home/z/my-project/db/restore-test.db')) {
    unlinkSync('/home/z/my-project/db/restore-test.db')
  }

  const src = createClient({ url: SOURCE })
  const dst = createClient({ url: RESTORE })

  const allStmts = splitSql(sql)
  // تخطي أوامر التحكم بالمعاملات: مشغّل libsql المحلي يعمل بـ auto-commit لكل أمر
  const ctrl = /^(\s*)(BEGIN|COMMIT|END|PRAGMA)/i
  const stmts = allStmts.filter((s) => !ctrl.test(s))
  console.log(`عدد الأوامر في الملف: ${allStmts.length} (منفّذة: ${stmts.length})`)

  for (const s of stmts) {
    await dst.execute(s)
  }
  console.log('✅ نُفّذت جميع الأوامر دون أخطاء')

  // مقارنة عدد الصفوف في كل جدول
  const tables = (await src.execute(
    "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
  )).rows.map((r) => String(r.name))

  let mismatch = 0
  for (const t of tables) {
    const a = Number((await src.execute(`SELECT COUNT(*) c FROM "${t}"`)).rows[0].c)
    const b = Number((await dst.execute(`SELECT COUNT(*) c FROM "${t}"`)).rows[0].c)
    if (a !== b) {
      console.log(`❌ ${t}: الأصل ${a} ≠ المستعاد ${b}`)
      mismatch++
    }
  }

  // تحقق عيني من بيانات المدير
  const admin = (await dst.execute("SELECT email, role, name FROM User WHERE email = 'admin@marsaa.ye'")).rows[0]
  console.log('المدير في القاعدة المستعادة:', JSON.stringify(admin))

  await src.close()
  await dst.close()
  unlinkSync('/home/z/my-project/db/restore-test.db')

  if (mismatch > 0) {
    console.error(`❌ فشل: ${mismatch} جدول غير متطابق`)
    process.exit(1)
  }
  console.log(`\n✅ تطابقت جميع الجداول (${tables.length}) بين الأصل والنسخة المستعادة — التفريغ سليم`)
}

main().catch((e) => {
  console.error('❌ فشل اختبار الاستعادة:', e)
  process.exit(1)
})
