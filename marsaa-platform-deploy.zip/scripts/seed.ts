// ============ سكربت البيانات الأولية ============
// تشغيل: bun scripts/seed.ts
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { SERVICE_TEMPLATES, DEFAULT_TEMPLATES, HS_CODES_SEED } from "../src/lib/seed-data";
import { DEFAULT_CLEARANCE_STAGES } from "../src/lib/constants";
import crypto from "crypto";

const db = new PrismaClient();

function trackingCode() {
  return crypto.randomBytes(16).toString("hex");
}

async function main() {
  console.log("🌱 بدء تهيئة البيانات...");

  // 1) مدير النظام
  const superAdminHash = await bcrypt.hash("Admin@2026", 10);
  const superAdmin = await db.user.upsert({
    where: { email: "admin@marsaa.ye" },
    update: {},
    create: {
      email: "admin@marsaa.ye",
      name: "مدير منصة مراسي",
      role: "SUPER_ADMIN",
      passwordHash: superAdminHash,
    },
  });
  console.log("✓ مدير النظام: admin@marsaa.ye / Admin@2026");

  // 2) الباقات
  const plans = [
    { name: "الأساسية", description: "للمكاتب الصغيرة والناشئة", maxUsers: 3, maxStorageMb: 1024, maxMonthlyReqs: 50, whatsappEnabled: false, priceMonthly: 35, priceYearly: 350, isDefault: true },
    { name: "الاحترافية", description: "للمكاتب النشطة في التخليص", maxUsers: 8, maxStorageMb: 5120, maxMonthlyReqs: 300, whatsappEnabled: true, priceMonthly: 75, priceYearly: 750, isDefault: false },
    { name: "الأعمال", description: "للمكاتب الكبيرة متعددة الفروع", maxUsers: 25, maxStorageMb: 20480, maxMonthlyReqs: 2000, whatsappEnabled: true, priceMonthly: 150, priceYearly: 1500, isDefault: false },
  ];
  for (const p of plans) {
    await db.plan.upsert({ where: { id: (await db.plan.findFirst({ where: { name: p.name } }))?.id ?? "___" }, update: p, create: p });
  }
  console.log("✓ الباقات (3)");

  // 3) جدول HS Code
  for (const hs of HS_CODES_SEED) {
    await db.hSCode.upsert({ where: { code: hs.code }, update: hs, create: hs });
  }
  console.log(`✓ جدول HS Code (${HS_CODES_SEED.length} رمزاً)`);

  // 4) المكتب التجريبي
  const proPlan = await db.plan.findFirst({ where: { name: "الاحترافية" } });
  let office = await db.office.findUnique({ where: { slug: "red-sea" } });
  if (!office) {
    office = await db.office.create({
      data: {
        name: "مكتب البحر الأحمر للتخليص الجمركي",
        slug: "red-sea",
        activityType: "CLEARANCE",
        phone: "+967 77 123 4567",
        whatsapp: "+967 77 123 4567",
        email: "info@redsea-clearance.ye",
        address: "عدن - كريتر - الشارع العام",
        city: "عدن",
        managerName: "أحمد عبدالله",
        brandColor: "#0F766E",
        workingHours: "السبت - الخميس: 8 صباحاً - 4 عصراً",
        about: "مكتب مخلص جمركي معتمد بخبرة تفوق 15 عاماً في تخليص البضائع عبر ميناء عدن والمنافذ البرية. نقدم خدمات التدقيق المستندي، التصنيف الجمركي، ومتابعة الإفراج النهائي باحترافية وسرعة.",
        status: "ACTIVE",
      },
    });
    // الترخيص
    await db.license.create({
      data: {
        officeId: office.id,
        key: "MRX-DEMO-2026-RED1",
        planId: proPlan?.id,
        durationDays: 365,
        startDate: new Date(),
        endDate: new Date(Date.now() + 320 * 86400000),
        status: "ACTIVE",
        activatedAt: new Date(),
      },
    });
    // أسعار الصرف
    await db.exchangeRate.createMany({
      data: [
        { officeId: office.id, currency: "USD", rate: 1590 },
        { officeId: office.id, currency: "SAR", rate: 424 },
      ],
    });
  }
  console.log("✓ المكتب التجريبي: red-sea (نشط)");

  const officeId = office.id;

  // 5) مستخدمو المكتب
  const officeUsers = [
    { email: "admin@redsea-clearance.ye", name: "أحمد عبدالله", role: "OFFICE_ADMIN", password: "Office@2026", phone: "+967 77 123 4567" },
    { email: "sara@redsea-clearance.ye", name: "سارة حسن", role: "STAFF", password: "Staff@2026", phone: "+967 71 234 5678" },
    { email: "broker@redsea-clearance.ye", name: "علي المخلص", role: "BROKER", password: "Broker@2026", phone: "+967 73 345 6789" },
    { email: "accountant@redsea-clearance.ye", name: "فاطمة المحاسب", role: "ACCOUNTANT", password: "Acc@2026", phone: "+967 77 456 7890" },
  ];
  const users: Record<string, string> = {};
  for (const u of officeUsers) {
    const hash = await bcrypt.hash(u.password, 10);
    const existing = await db.user.findUnique({ where: { email: u.email } });
    const user = existing ?? (await db.user.create({
      data: { officeId, email: u.email, name: u.name, role: u.role, passwordHash: hash, phone: u.phone, isActive: true },
    }));
    users[u.role] = user.id;
  }
  console.log("✓ مستخدمو المكتب (مدير، موظفة، مخلص، محاسبة)");

  // 6) كتالوج الخدمات من القوالب
  const catMap: Record<string, string> = {};
  for (const tpl of SERVICE_TEMPLATES) {
    if (!catMap[tpl.categoryName]) {
      let cat = await db.serviceCategory.findFirst({ where: { officeId, name: tpl.categoryName } });
      if (!cat) {
        cat = await db.serviceCategory.create({
          data: { officeId, name: tpl.categoryName, sortOrder: Object.keys(catMap).length, isActive: true },
        });
      }
      catMap[tpl.categoryName] = cat.id;
    }
    let svc = await db.service.findFirst({ where: { officeId, name: tpl.name } });
    if (!svc) {
      svc = await db.service.create({
        data: {
          officeId,
          categoryId: catMap[tpl.categoryName],
          name: tpl.name,
          description: tpl.description,
          icon: tpl.icon,
          price: tpl.price,
          priceLabel: tpl.priceLabel,
          estimatedDays: tpl.estimatedDays,
          isClearance: tpl.isClearance,
          isActive: true,
          sortOrder: 0,
          requiredDocs: { create: tpl.requiredDocs.map((d, i) => ({ name: d.name, isMandatory: d.isMandatory, description: d.description, sortOrder: i })) },
          stages: { create: (tpl.stages ?? DEFAULT_CLEARANCE_STAGES).map((name, i) => ({ name, sortOrder: i, isVisibleToClient: true, notifyClient: i === (tpl.stages ?? DEFAULT_CLEARANCE_STAGES).length - 1 })) },
          formFields: { create: tpl.formFields.map((f, i) => ({ key: f.key, label: f.label, type: f.type, options: f.options, isRequired: f.isRequired, placeholder: f.placeholder, sortOrder: i })) },
        },
      });
    }
  }
  console.log("✓ كتالوج الخدمات (7 خدمات من القوالب الجاهزة)");

  // 7) قوالب الإشعارات للمكتب
  for (const t of DEFAULT_TEMPLATES) {
    const existing = await db.notificationTemplate.findFirst({ where: { officeId, event: t.event, channel: t.channel } });
    if (!existing) {
      await db.notificationTemplate.create({ data: { officeId, event: t.event, channel: t.channel, subject: t.subject, body: t.body, isActive: true } });
    }
  }
  console.log("✓ قوالب الإشعارات");

  // 8) العملاء التجريبيون
  const clientHash = await bcrypt.hash("Client@2026", 10);
  let alnoor = await db.customer.findFirst({ where: { officeId, name: "شركة النور للتجارة والاستيراد" } });
  if (!alnoor) {
    alnoor = await db.customer.create({
      data: {
        officeId,
        name: "شركة النور للتجارة والاستيراد",
        customerType: "COMPANY",
        taxNumber: "3001234567",
        crNumber: "12345",
        phone: "+967 77 200 3000",
        whatsapp: "+967 77 200 3000",
        email: "client@alnoor.ye",
        address: "عدن - المنصورة",
        passwordHash: clientHash,
      },
    });
  }
  let mohammed = await db.customer.findFirst({ where: { officeId, name: "محمد سالم باعوم" } });
  if (!mohammed) {
    mohammed = await db.customer.create({
      data: {
        officeId,
        name: "محمد سالم باعوم",
        customerType: "INDIVIDUAL",
        phone: "+967 71 111 2222",
        whatsapp: "+967 71 111 2222",
        email: "mohammed@mail.com",
        address: "عدن - خور مكسر",
        passwordHash: clientHash,
      },
    });
  }
  let alamal = await db.customer.findFirst({ where: { officeId, name: "شركة الأمل للمواد الغذائية" } });
  if (!alamal) {
    alamal = await db.customer.create({
      data: {
        officeId,
        name: "شركة الأمل للمواد الغذائية",
        customerType: "COMPANY",
        taxNumber: "3007654321",
        crNumber: "67890",
        phone: "+967 77 900 8000",
        whatsapp: "+967 77 900 8000",
        address: "عدن - كريتر",
      },
    });
  }
  console.log("✓ العملاء (عميل بريد/كلمة مرور: client@alnoor.ye / Client@2026)");

  // 9) الطلبات التجريبية
  const svcContainer = await db.service.findFirst({ where: { officeId, name: "تخليص حاوية 20 قدم" } });
  const svcRice = await db.service.findFirst({ where: { officeId, name: "تخليص بضائع عامة (LCL)" } });
  const svcTax = await db.service.findFirst({ where: { officeId, name: "تجديد البطاقة الضريبية" } });
  const svcSpec = await db.service.findFirst({ where: { officeId, name: "فحص مطابقة المواصفات والمقاييس" } });
  const hsRice = await db.hSCode.findUnique({ where: { code: "100630" } });
  const hsAC = await db.hSCode.findUnique({ where: { code: "841581" } });

  const now = new Date();
  const daysAgo = (n: number) => new Date(now.getTime() - n * 86400000);

  async function createRequest(opts: {
    customer: string; service: string; status: string; number: string;
    formData?: Record<string, string>; estimatedDays?: number; assignedTo?: string;
    createdByStaff?: string; stageOrder?: number; rating?: number;
  }) {
    const existing = await db.request.findUnique({ where: { requestNumber: opts.number } });
    if (existing) return existing;
    const svc = opts.service;
    const acceptedAt = [ "ACCEPTED", "IN_PROGRESS", "READY", "COMPLETED", "DELIVERED" ].includes(opts.status) ? daysAgo(6) : null;
    const expected = acceptedAt && svc?.estimatedDays ? new Date(acceptedAt.getTime() + (svc.estimatedDays + 2) * 86400000) : null;
    const completedAt = ["READY", "COMPLETED", "DELIVERED"].includes(opts.status) ? daysAgo(1) : null;
    const stages = svc ? await db.serviceStage.findMany({ where: { serviceId: svc.id }, orderBy: { sortOrder: "asc" } }) : [];
    const currentStage = opts.stageOrder !== undefined ? stages[Math.min(opts.stageOrder, stages.length - 1)]?.id : null;

    const req = await db.request.create({
      data: {
        officeId,
        requestNumber: opts.number,
        customerId: opts.customer,
        serviceId: svc!.id,
        status: opts.status,
        currentStageId: currentStage,
        trackingCode: trackingCode(),
        formData: JSON.stringify(opts.formData ?? {}),
        estimatedDays: opts.estimatedDays ?? svc?.estimatedDays,
        acceptedAt,
        expectedCompletion: expected,
        completedAt,
        deliveredAt: opts.status === "DELIVERED" ? daysAgo(0) : null,
        completionNotified: ["READY", "COMPLETED", "DELIVERED"].includes(opts.status) ? daysAgo(1) : null,
        rating: opts.rating,
        assignedToId: opts.assignedTo,
        createdByStaffId: opts.createdByStaff,
        createdAt: daysAgo(8),
      },
    });
    // سجل الحالات
    const flow = ["SUBMITTED", "UNDER_REVIEW", opts.status];
    let prev: string | null = null;
    for (const s of flow) {
      await db.requestStatusHistory.create({
        data: {
          requestId: req.id, fromStatus: prev, toStatus: s,
          note: s === "SUBMITTED" ? "تم إرسال الطلب من قبل العميل" : null,
          actorType: s === "SUBMITTED" ? "CUSTOMER" : "STAFF",
          actorName: s === "SUBMITTED" ? "بوابة العميل" : "سارة حسن",
          createdAt: daysAgo(8),
        },
      });
      prev = s;
    }
    return req;
  }

  // طلب 1: تخليص حاوية 20 قدم — قيد التنفيذ
  const r1 = await createRequest({
    customer: alnoor.id, service: svcContainer!, status: "IN_PROGRESS", number: "RED-2026-0001",
    formData: {
      bl_number: "MSCU-2026-118342", container_no: "MSCU1234567",
      goods_desc: "مواد غذائية متنوعة: أرز بسمتي، سكر، زيت طعام",
      supplier: "Golden Rice Trading Co.", origin: "الهند", arrival_date: daysAgo(7).toISOString().slice(0, 10),
    },
    assignedTo: users["BROKER"], stageOrder: 3,
  });
  await db.shipment.create({
    data: {
      requestId: r1.id, officeId,
      billOfLadingNo: "MSCU-2026-118342", containerNos: "MSCU1234567", containerType: "20FT",
      supplierName: "Golden Rice Trading Co.", importerName: "شركة النور للتجارة والاستيراد",
      originCountry: "الهند", arrivalPort: "ميناء عدن", carrier: "MSC",
      arrivalDate: daysAgo(7), declarationNo: "ADN-2026-45231",
      goodsType: "مواد غذائية", weight: 18500, packagesCount: 850,
      value: 42000, currency: "USD",
      items: {
        create: [
          { description: "أرز بسمتي هندي فاخر", hsCodeId: hsRice?.id, hsCodeText: "100630", originCountry: "الهند", quantity: 600, unit: "شوال", weight: 12000, value: 24000, currency: "USD", dutyRate: 5 },
          { description: "سكر أبيض مكرر", hsCodeId: (await db.hSCode.findUnique({ where: { code: "170199" } }))?.id, hsCodeText: "170199", originCountry: "البرازيل", quantity: 250, unit: "شوال", weight: 5000, value: 13000, currency: "USD", dutyRate: 20 },
        ],
      },
      steps: {
        create: [
          { type: "DECLARATION", title: "فتح البيان الجمركي رقم ADN-2026-45231", status: "DONE", result: "PASS", scheduledAt: daysAgo(5), notes: "تم الفتح بنجاح" },
          { type: "INSPECTION", title: "لجنة الكشف والمعاينة — ميناء عدن", status: "DONE", result: "PASS", scheduledAt: daysAgo(3), notes: "لا توجد ملاحظات، البضاعة مطابقة" },
          { type: "STANDARDS", title: "فحص هيئة المواصفات — الأرز والسكر", status: "PENDING", scheduledAt: daysAgo(-1), notes: "بانتظار نتيجة المختبر" },
        ],
      },
      checklist: {
        create: [
          { label: "الفاتورة التجارية", isDone: true, sortOrder: 0, doneAt: daysAgo(6) },
          { label: "بوليصة الشحن", isDone: true, sortOrder: 1, doneAt: daysAgo(6) },
          { label: "قائمة التعبئة", isDone: true, sortOrder: 2, doneAt: daysAgo(6) },
          { label: "شهادة المنشأ", isDone: true, sortOrder: 3, doneAt: daysAgo(6) },
          { label: "إذن التسليم", isDone: true, sortOrder: 4, doneAt: daysAgo(5) },
          { label: "سداد الرسوم والضرائب", isDone: false, sortOrder: 5 },
          { label: "إذن الإفراج النهائي", isDone: false, sortOrder: 6 },
        ],
      },
    },
  });

  // طلب 2: تجديد بطاقة ضريبية — مكتمل ومسدد
  const r2 = await createRequest({
    customer: alnoor.id, service: svcTax!, status: "DELIVERED", number: "RED-2026-0002",
    formData: { tax_number: "3001234567", owner_name: "شركة النور للتجارة" },
    stageOrder: 4, rating: 5,
  });
  await db.costItem.createMany({
    data: [
      { officeId, requestId: r2.id, category: "REGULATORY", label: "رسوم تجديد البطاقة الضريبية", amount: 12000, currency: "YER", exchangeRate: 1, amountBase: 12000, isOfficeFee: false, createdByName: "سارة حسن", createdAt: daysAgo(4) },
      { officeId, requestId: r2.id, category: "OFFICE_FEE", label: "أتعاب المكتب — تجديد بطاقة ضريبية", amount: 15000, currency: "YER", exchangeRate: 1, amountBase: 15000, isOfficeFee: true, createdByName: "سارة حسن", createdAt: daysAgo(4) },
    ],
  });
  await db.payment.create({
    data: { officeId, customerId: alnoor.id, requestId: r2.id, amount: 27000, currency: "YER", exchangeRate: 1, amountBase: 27000, method: "CASH", reference: "CASH-0021", receivedByName: "فاطمة المحاسب", createdAt: daysAgo(2) },
  });
  await db.invoice.create({
    data: {
      officeId, customerId: alnoor.id, requestId: r2.id, invoiceNumber: "INV-2026-0001",
      items: JSON.stringify([
        { label: "رسوم تجديد البطاقة الضريبية", amount: 12000 },
        { label: "أتعاب المكتب — تجديد بطاقة ضريبية", amount: 15000 },
      ]),
      subtotal: 27000, total: 27000, currency: "YER", status: "PAID", issueDate: daysAgo(3),
    },
  });

  // طلب 3: تخليص بضائع عامة — بانتظار استكمال العميل
  await createRequest({
    customer: mohammed.id, service: svcRice!, status: "AWAITING_CLIENT", number: "RED-2026-0003",
    formData: { bl_number: "AWB-116-88213455", goods_desc: "قطع غيار سيارات متنوعة", weight: "1200" },
    stageOrder: 1,
  });

  // طلب 4: فحص مواصفات — مُرسَل جديد
  await createRequest({
    customer: alamal.id, service: svcSpec!, status: "SUBMITTED", number: "RED-2026-0004",
    formData: { goods_desc: "أجهزة تكييف سبليت 1.5 طن", hs_code: "841581" },
  });

  // طلب 5: نيابة عن العميل (FR-OF-18)
  const r5 = await createRequest({
    customer: alamal.id, service: svcContainer!, status: "ACCEPTED", number: "RED-2026-0005",
    formData: { bl_number: "CMAU-2026-77120", container_no: "CMAU7712330", goods_desc: "مواد بناء: أسمنت وألواح", supplier: "Building Materials Co.", origin: "الإمارات" },
    createdByStaff: users["STAFF"], stageOrder: 0,
  });
  await db.comment.create({
    data: { requestId: r5.id, officeId, authorType: "STAFF", authorName: "سارة حسن", body: "تم إدخال الطلب نيابةً عن العميل عبر الهاتف — بانتظار حضورهم للمستندات الورقية.", isInternal: false, createdAt: daysAgo(2) },
  });

  // مستندات الطلبات (بدون ملفات فعلية — حالات تدقيق مختلفة)
  async function addDocs(requestId: string, svcId: string, statuses: { name: string; status: string }[]) {
    for (const d of statuses) {
      const existing = await db.requestDocument.findFirst({ where: { requestId, name: d.name } });
      if (existing) continue;
      await db.requestDocument.create({
        data: {
          requestId, officeId, name: d.name, status: d.status,
          uploadedByType: "CUSTOMER", uploadedByName: "بوابة العميل",
          reviewNote: d.status === "REJECTED" ? "الصورة غير واضحة، يرجى رفع نسخة أوضح" : null,
        },
      });
    }
  }
  await addDocs(r1.id, svcContainer!.id, [
    { name: "الفاتورة التجارية", status: "APPROVED" },
    { name: "بوليصة الشحن", status: "APPROVED" },
    { name: "قائمة التعبئة", status: "APPROVED" },
    { name: "شهادة المنشأ", status: "APPROVED" },
    { name: "إذن التسليم", status: "UPLOADED" },
    { name: "السجل التجاري للمستورد", status: "APPROVED" },
    { name: "البطاقة الضريبية للمستورد", status: "APPROVED" },
  ]);
  await addDocs(r2.id, svcTax!.id, [
    { name: "صورة البطاقة الضريبية الحالية", status: "APPROVED" },
    { name: "السجل التجاري ساري المفعول", status: "APPROVED" },
  ]);

  // 10) إعدادات المنصة
  const settings = [
    { key: "platform_name", value: "منصة مراسي" },
    { key: "platform_tagline", value: "منصة إدارة مكاتب السفر والتخليص الجمركي" },
    { key: "email_provider", value: "محاكاة (سجل الإرسال) — جاهز للربط بمزود SMTP" },
    { key: "whatsapp_provider", value: "محاكاة (سجل الإرسال) — جاهز للربط بـ WhatsApp Business API" },
    { key: "backup_daily", value: "مفعّل" },
  ];
  for (const s of settings) {
    await db.platformSetting.upsert({ where: { key: s.key }, update: { value: s.value }, create: s });
  }

  // تحديث عداد الطلبات
  await db.office.update({ where: { id: officeId }, data: { reqCounter: 5 } });

  console.log("✓ الطلبات التجريبية (5 طلبات بحالات مختلفة)");
  console.log("\n🎉 اكتملت التهيئة!");
  console.log("═══ بيانات الدخول ═══");
  console.log("مدير النظام: admin@marsaa.ye / Admin@2026");
  console.log("مدير المكتب: admin@redsea-clearance.ye / Office@2026");
  console.log("موظفة: sara@redsea-clearance.ye / Staff@2026");
  console.log("مخلص ميداني: broker@redsea-clearance.ye / Broker@2026");
  console.log("محاسبة: accountant@redsea-clearance.ye / Acc@2026");
  console.log("عميل: client@alnoor.ye / Client@2026");
  console.log("رابط المكتب العام: /o/red-sea");
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => db.$disconnect());
