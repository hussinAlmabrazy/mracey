// فحص بيانات دخول الحسابات الاختبارية بعد اختبارات إعدادات الحساب
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

async function main() {
  const checks = [
    { model: db.user, where: { email: "admin@marsaa.ye" }, pass: "Admin@2026", label: "مدير المنصة" },
    { model: db.user, where: { email: "admin@redsea-clearance.ye" }, pass: "Office@2026", label: "مدير المكتب" },
    { model: db.user, where: { email: "sara@redsea-clearance.ye" }, pass: "Staff@2026", label: "الموظفة سارة" },
    { model: db.customer, where: { email: "client@alnoor.ye" }, pass: "Client@2026", label: "العميل", first: true },
  ];
  for (const c of checks as any[]) {
    const row = c.first ? await c.model.findFirst({ where: c.where }) : await c.model.findUnique({ where: c.where });
    const ok = row?.passwordHash ? await bcrypt.compare(c.pass, row.passwordHash) : false;
    console.log(`${ok ? "OK " : "FAIL"} | ${c.label} | ${c.where.email} | ${c.pass}`);
  }
  const client = await db.customer.findFirst({ where: { email: "client@alnoor.ye" } });
  console.log(`عميل phone=${client?.phone} whatsapp=${client?.whatsapp}`);
}

main().finally(() => db.$disconnect());
