/* eslint-disable @typescript-eslint/no-require-imports */ // سكربت تحقق واحد الإصدار — يستخدم require
// فحص حالة مكتب بن خليل والخدمات في قاعدة البيانات
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();

async function main() {
  const offices = await db.office.findMany({
    select: { id: true, name: true, slug: true, status: true, createdAt: true },
  });
  console.log("=== المكاتب ===");
  for (const o of offices) {
    const services = await db.service.count({ where: { officeId: o.id } });
    const categories = await db.serviceCategory.count({ where: { officeId: o.id } });
    const staff = await db.user.findMany({
      where: { officeId: o.id },
      select: { email: true, role: true, name: true, isActive: true },
    });
    console.log(`- ${o.name} | slug: ${o.slug} | status: ${o.status}`);
    console.log(`  الخدمات: ${services} | التصنيفات: ${categories}`);
    console.log(`  الموظفون:`, JSON.stringify(staff));
  }

  console.log("\n=== عينة خدمات (أول مكتب لديه خدمات) ===");
  const sampleServices = await db.service.findMany({
    take: 5,
    select: { name: true, officeId: true, isActive: true },
  });
  console.log(JSON.stringify(sampleServices, null, 2));

  console.log("\n=== قوالب الخدمات (SERVICE_TEMPLATES) ===");
  console.log("تُعرض دائماً في واجهة إدارة الخدمات بغض النظر عن بيانات المكتب");
}

main().catch(console.error).finally(() => db.$disconnect());
