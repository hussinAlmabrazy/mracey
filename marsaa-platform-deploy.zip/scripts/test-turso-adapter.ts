// ============================================================
// اختبار محول Turso/libSQL محلياً — يمرر قاعدة SQLite الحالية
// عبر نفس مسار السحابة في src/lib/db.ts (وضع file:)
// يثبت أن القراءة والكتابة عبر @prisma/adapter-libsql تعمل
// ============================================================
process.env.TURSO_DATABASE_URL = 'file:/home/z/my-project/db/custom.db'
process.env.TURSO_AUTH_TOKEN = ''

async function main() {
  const { db } = await import('../src/lib/db')

  // 1) قراءة: مستخدم مدير المنصة
  const admin = await db.user.findUnique({
    where: { email: 'admin@marsaa.ye' },
    select: { id: true, email: true, role: true, name: true, lastLoginAt: true },
  })
  if (!admin) throw new Error('لم يتم العثور على مستخدم المدير!')
  console.log('[قراءة] مدير المنصة:', { email: admin.email, role: admin.role, name: admin.name })

  // 2) قراءة: إحصاءات الجداول الرئيسية
  const offices = await db.office.count()
  const services = await db.service.count()
  const customers = await db.customer.count()
  const users = await db.user.count()
  console.log(`[قراءة] مكاتب=${offices} | خدمات=${services} | عملاء=${customers} | مستخدمون=${users}`)

  // 3) كتابة: تحديث lastLoginAt (حقل آمن يتغير طبيعياً عند الدخول)
  await db.user.update({
    where: { id: admin.id },
    data: { lastLoginAt: new Date() },
  })
  const after = await db.user.findUnique({
    where: { id: admin.id },
    select: { lastLoginAt: true },
  })
  console.log('[كتابة] تحديث lastLoginAt عبر المحول →', after?.lastLoginAt)

  // 4) إنشاء + قراءة + حذف سجل مؤقت (PlatformSetting)
  await db.platformSetting.create({ data: { key: '__turso_adapter_test__', value: 'ok' } })
  const tmp = await db.platformSetting.findUnique({ where: { key: '__turso_adapter_test__' } })
  if (tmp?.value !== 'ok') throw new Error('فشل إنشاء السجل المؤقت!')
  await db.platformSetting.delete({ where: { key: '__turso_adapter_test__' } })
  console.log('[كتابة] إنشاء/حذف سجل مؤقت عبر المحول → نجح')

  await db.$disconnect()
  console.log('\n✅ نجحت جميع اختبارات محول Turso/libSQL (قراءة + كتابة + إنشاء + حذف)')
}

main().catch((e) => {
  console.error('❌ فشل اختبار المحول:', e)
  process.exit(1)
})
