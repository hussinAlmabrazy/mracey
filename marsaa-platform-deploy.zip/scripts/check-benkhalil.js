/* eslint-disable @typescript-eslint/no-require-imports */ // سكربت تحقق واحد الإصدار — يستخدم require
// فحص خدمات مكتب بن خليل بالتفصيل
const { PrismaClient } = require("@prisma/client");
const db = new PrismaClient();

async function main() {
  const office = await db.office.findFirst({
    where: { slug: "benkalal-com" },
    select: { id: true, name: true },
  });
  if (!office) return console.log("المكتب غير موجود");

  const services = await db.service.findMany({
    where: { officeId: office.id },
    orderBy: { createdAt: "asc" },
    select: {
      name: true, isActive: true, createdAt: true, price: true,
      category: { select: { name: true } },
      _count: { select: { requiredDocs: true, stages: true, formFields: true } },
    },
  });

  console.log(`=== خدمات ${office.name} ===`);
  for (const s of services) {
    console.log(
      `- ${s.name} | نشطة: ${s.isActive} | تصنيف: ${s.category?.name || "بدون"} | سعر: ${s.price ?? "حسب الطلب"} | مستندات: ${s._count.requiredDocs} | مراحل: ${s._count.stages} | حقول: ${s._count.formFields} | أُنشئت: ${s.createdAt.toISOString()}`
    );
  }

  const cats = await db.serviceCategory.findMany({
    where: { officeId: office.id },
    select: { name: true, createdAt: true },
  });
  console.log("\n=== التصنيفات ===");
  for (const c of cats) console.log(`- ${c.name} | ${c.createdAt.toISOString()}`);
}

main().catch(console.error).finally(() => db.$disconnect());
