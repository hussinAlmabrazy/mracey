// توليد كوكيز جلسات موقّعة للاختبار الدخاني للمسارات المحمية
import { SignJWT } from "jose";
import fs from "fs";

const secret = new TextEncoder().encode(process.env.AUTH_SECRET || fs.readFileSync(".env", "utf8").match(/AUTH_SECRET=(.*)/)?.[1] || "dev");

async function sign(payload: Record<string, unknown>) {
  return new SignJWT(payload).setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("7d").sign(secret);
}

const officeAdmin = await sign({ sub: process.argv[2], type: "USER", role: "OFFICE_ADMIN", officeId: process.argv[3], name: "Test" });
const superAdmin = await sign({ sub: process.argv[4], type: "USER", role: "SUPER_ADMIN", officeId: null, name: "Test" });
const customer = await sign({ sub: process.argv[5], type: "CUSTOMER", officeId: process.argv[3], name: "Test" });

console.log(JSON.stringify({ officeAdmin, superAdmin, customer }));
