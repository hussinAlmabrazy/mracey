"use server";

import { redirect } from "next/navigation";
import { db } from "@/lib/db";
import { setUserSession, clearUserSession, verifyPassword, setCustomerSession, clearCustomerSession, hashPassword } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { DEFAULT_TEMPLATES } from "@/lib/seed-data";

export type LoginState = { error?: string } | undefined;

/** دخول موظفي المكاتب ومدير النظام (بريد واحد فريد عالمياً) */
export async function loginStaff(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const password = String(formData.get("password") || "");
  if (!email || !password) return { error: "يرجى إدخال البريد الإلكتروني وكلمة المرور" };

  const user = await db.user.findUnique({ where: { email }, include: { office: { select: { id: true, name: true, status: true, slug: true } } } });
  if (!user || !user.passwordHash || !(await verifyPassword(password, user.passwordHash))) {
    return { error: "بيانات الدخول غير صحيحة" };
  }
  if (!user.isActive) return { error: "الحساب معطّل — تواصل مع مدير مكتبك" };

  if (user.role === "SUPER_ADMIN") {
    await setUserSession({ sub: user.id, type: "USER", role: "SUPER_ADMIN", officeId: null, name: user.name });
    await audit({ actorType: "SUPER_ADMIN", actorId: user.id, actorName: user.name }, "LOGIN", "USER", user.id);
    redirect("/admin");
  }

  const office = user.office;
  if (!office) return { error: "لا يوجد مكتب مرتبط بالحساب" };
  if (office.status === "SUSPENDED") return { error: "ترخيص المكتب موقوف حالياً — تواصل مع إدارة المنصة" };
  if (office.status === "ARCHIVED" || office.status === "PENDING") return { error: "المكتب غير مفعّل بعد — فعّل الحساب بالمفتاح أولاً" };

  await db.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
  await setUserSession({ sub: user.id, type: "USER", role: user.role, officeId: office.id, name: user.name });
  await audit({ actorType: "STAFF", actorId: user.id, actorName: user.name }, "LOGIN", "USER", user.id, office.id);
  redirect("/office");
}

export async function logoutStaff(): Promise<void> {
  const session = await getUserSessionSafe();
  if (session) {
    await audit(
      { actorType: session.role === "SUPER_ADMIN" ? "SUPER_ADMIN" : "STAFF", actorId: session.sub, actorName: session.name },
      "LOGOUT", "USER", session.sub, session.officeId
    );
  }
  await clearUserSession();
  redirect("/");
}

async function getUserSessionSafe() {
  try {
    const { getUserSession } = await import("@/lib/auth");
    return await getUserSession();
  } catch {
    return null;
  }
}

/** تفعيل حساب المكتب بالمفتاح وإنشاء كلمة مرور المدير */
export async function activateOffice(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const key = String(formData.get("key") || "").trim().toUpperCase();
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const name = String(formData.get("name") || "").trim();
  const password = String(formData.get("password") || "");
  if (!key || !email || !name || !password) return { error: "يرجى تعبئة جميع الحقول" };
  if (password.length < 8) return { error: "كلمة المرور يجب أن تكون 8 أحرف على الأقل" };

  const license = await db.license.findUnique({ where: { key }, include: { office: true } });
  if (!license) return { error: "مفتاح التفعيل غير صحيح" };
  if (license.status === "REVOKED") return { error: "هذا المفتاح ملغى — تواصل مع إدارة المنصة" };
  if (license.status === "ACTIVE" && license.activatedAt) return { error: "هذا المفتاح مستخدم بالفعل" };

  const existingEmail = await db.user.findUnique({ where: { email } });
  if (existingEmail) return { error: "البريد الإلكتروني مستخدم مسبقاً" };

  const now = new Date();
  const endDate = new Date(now.getTime() + license.durationDays * 86400000);
  await db.$transaction(async (tx) => {
    const office = await tx.office.update({
      where: { id: license.officeId },
      data: { status: "ACTIVE", managerName: name, email },
    });
    await tx.license.update({
      where: { id: license.id },
      data: { status: "ACTIVE", startDate: now, endDate, activatedAt: now },
    });
    await tx.user.create({
      data: { officeId: office.id, email, name, role: "OFFICE_ADMIN", passwordHash: await hashPassword(password), isActive: true },
    });
    // قوالب الإشعارات الافتراضية للمكتب
    for (const t of DEFAULT_TEMPLATES) {
      const exists = await tx.notificationTemplate.findFirst({ where: { officeId: office.id, event: t.event, channel: t.channel } });
      if (!exists) {
        await tx.notificationTemplate.create({ data: { officeId: office.id, event: t.event, channel: t.channel, subject: t.subject, body: t.body } });
      }
    }
    // أسعار صرف افتراضية
    for (const cur of ["USD", "SAR"]) {
      await tx.exchangeRate.upsert({
        where: { officeId_currency: { officeId: office.id, currency: cur } },
        update: {},
        create: { officeId: office.id, currency: cur, rate: cur === "USD" ? 1590 : 424 },
      });
    }
    await tx.auditLog.create({
      data: { officeId: office.id, actorType: "STAFF", actorName: name, action: "LICENSE", entityType: "Office", entityId: office.id, details: JSON.stringify({ key, activated: true }) },
    });
  });

  // دخول مباشر بعد التفعيل
  const user = await db.user.findUnique({ where: { email } });
  if (user) {
    await setUserSession({ sub: user.id, type: "USER", role: "OFFICE_ADMIN", officeId: license.officeId, name });
    redirect("/office");
  }
  return { error: "حدث خطأ غير متوقع" };
}

/** تسجيل عميل جديد لدى مكتب محدد */
export async function registerCustomer(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const slug = String(formData.get("slug") || "");
  const name = String(formData.get("name") || "").trim();
  const customerType = String(formData.get("customerType") || "INDIVIDUAL");
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const phone = String(formData.get("phone") || "").trim();
  const whatsapp = String(formData.get("whatsapp") || "").trim();
  const password = String(formData.get("password") || "");
  const address = String(formData.get("address") || "").trim();
  const taxNumber = String(formData.get("taxNumber") || "").trim();
  const crNumber = String(formData.get("crNumber") || "").trim();

  if (!name || !phone || !password) return { error: "الاسم ورقم الجوال وكلمة المرور حقول إلزامية" };
  if (password.length < 8) return { error: "كلمة المرور يجب أن تكون 8 أحرف على الأقل" };

  const office = await db.office.findUnique({ where: { slug } });
  if (!office || office.status !== "ACTIVE") return { error: "المكتب غير متاح للتسجيل حالياً" };

  const duplicate = await db.customer.findFirst({
    where: { officeId: office.id, OR: [{ phone }, ...(email ? [{ email }] : [])] },
  });
  if (duplicate) return { error: "يوجد حساب بهذا الجوال أو البريد لدى هذا المكتب — سجّل الدخول" };

  const customer = await db.customer.create({
    data: {
      officeId: office.id, name, customerType, email: email || null, phone, whatsapp: whatsapp || phone,
      address: address || null, taxNumber: taxNumber || null, crNumber: crNumber || null,
      passwordHash: await hashPassword(password),
    },
  });
  await audit({ actorType: "CUSTOMER", actorId: customer.id, actorName: name }, "CREATE", "Customer", customer.id, office.id, { registered: true });
  await setCustomerSession({ sub: customer.id, type: "CUSTOMER", officeId: office.id, name });
  redirect(`/o/${slug}/portal`);
}

/** دخول العميل (بريد أو جوال + كلمة مرور) داخل نطاق المكتب */
export async function loginCustomer(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const slug = String(formData.get("slug") || "");
  const identifier = String(formData.get("identifier") || "").trim().toLowerCase();
  const password = String(formData.get("password") || "");
  if (!identifier || !password) return { error: "يرجى إدخال البريد/الجوال وكلمة المرور" };

  const office = await db.office.findUnique({ where: { slug } });
  if (!office) return { error: "المكتب غير موجود" };

  const customer = await db.customer.findFirst({
    where: { officeId: office.id, OR: [{ email: identifier }, { phone: identifier }] },
  });
  if (!customer || !customer.passwordHash || !(await verifyPassword(password, customer.passwordHash))) {
    return { error: "بيانات الدخول غير صحيحة" };
  }
  await db.customer.update({ where: { id: customer.id }, data: { lastLoginAt: new Date() } });
  await audit({ actorType: "CUSTOMER", actorId: customer.id, actorName: customer.name }, "LOGIN", "Customer", customer.id, office.id);
  await setCustomerSession({ sub: customer.id, type: "CUSTOMER", officeId: office.id, name: customer.name });
  redirect(`/o/${slug}/portal`);
}

export async function logoutCustomer(): Promise<void> {
  await clearCustomerSession();
  redirect("/");
}
