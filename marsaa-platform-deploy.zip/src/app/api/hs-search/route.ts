import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

/** GET /api/hs-search?q=... — البحث في جدول HS Code بالرمز أو الوصف (عربي/إنجليزي) */
export async function GET(req: NextRequest) {
  const q = (req.nextUrl.searchParams.get("q") || "").trim();
  if (q.length < 2) return NextResponse.json({ results: [] });

  const results = await db.hSCode.findMany({
    where: {
      isActive: true,
      OR: [
        { code: { contains: q } },
        { descriptionAr: { contains: q } },
        { descriptionEn: { contains: q } },
      ],
    },
    select: { id: true, code: true, descriptionAr: true, descriptionEn: true, unit: true, dutyRate: true, salesTaxRate: true },
    take: 15,
    orderBy: { code: "asc" },
  });
  return NextResponse.json({ results });
}
