import { NextRequest, NextResponse } from "next/server";
import { getUserSession, getCustomerSession } from "@/lib/auth";
import { readStoredFile } from "@/lib/files";
import { db } from "@/lib/db";
import { audit } from "@/lib/audit";

/**
 * GET /api/files/[...path] — تقديم ملف من التخزين المعزول بعد تحقق الصلاحيات:
 * - موظف المكتب أو مدير النظام: وصول كامل لملفات مكتبه
 * - العميل: فقط ملفات طلباته (مستندات طلبه أو مرفقاته)
 */
export async function GET(req: NextRequest, { params }: { params: Promise<{ path: string[] }> }) {
  try {
    const { path: parts } = await params;
    const relPath = parts.join("/");
    const officeId = parts[0]; // المسار يبدأ بمعرف المكتب

    if (!officeId) return NextResponse.json({ error: "مسار غير صالح" }, { status: 400 });

    const userSession = await getUserSession();
    const customerSession = await getCustomerSession();
    let allowed = false;
    let actorName = "";

    // وصول عام عبر رمز التتبع: المستندات النهائية للطلبات المكتملة فقط (FR-NT-06)
    const trackCode = req.nextUrl.searchParams.get("track");
    if (trackCode && relPath.startsWith(`requests/`)) {
      const trackedReq = await db.request.findUnique({
        where: { trackingCode: trackCode },
        select: { id: true, status: true },
      });
      if (trackedReq && ["READY", "COMPLETED", "DELIVERED"].includes(trackedReq.status) && relPath.includes(`/${trackedReq.id}/`)) {
        const doc = await db.requestDocument.findFirst({
          where: { filePath: relPath, uploadedByType: "STAFF" },
          select: { id: true },
        });
        if (doc) {
          allowed = true;
          actorName = "تتبع عام";
        }
      }
    }

    if (!allowed && userSession) {
      if (userSession.role === "SUPER_ADMIN") {
        allowed = true;
        actorName = userSession.name;
      } else if (userSession.officeId === officeId) {
        allowed = true;
        actorName = userSession.name;
      }
    } else if (!allowed && customerSession) {
      if (customerSession.officeId === officeId) {
        // العميل: الملف يجب أن يكون ضمن مستندات طلباته
        const doc = await db.requestDocument.findFirst({
          where: { filePath: relPath, request: { customerId: customerSession.sub } },
          select: { id: true },
        });
        const isClientUpload = relPath.includes(`/${customerSession.sub}/`);
        allowed = Boolean(doc || isClientUpload);
        actorName = customerSession.name;
      }
    }

    if (!allowed) {
      return NextResponse.json({ error: "غير مصرح بالوصول لهذا الملف" }, { status: 403 });
    }

    const file = await readStoredFile(relPath);
    if (!file) return NextResponse.json({ error: "الملف غير موجود" }, { status: 404 });

    await audit(
      { actorType: userSession ? "STAFF" : "CUSTOMER", actorName },
      "VIEW_FILE", "FILE", relPath, officeId, { via: "api" }
    );

    const inline = req.nextUrl.searchParams.get("dl") !== "1";
    return new NextResponse(new Uint8Array(file.buffer), {
      headers: {
        "Content-Type": file.mime,
        "Content-Disposition": `${inline ? "inline" : "attachment"}; filename="file"`,
        "Cache-Control": "private, max-age=300",
      },
    });
  } catch {
    return NextResponse.json({ error: "خطأ في قراءة الملف" }, { status: 500 });
  }
}
