import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getUserSession } from "@/lib/auth";

/** GET /api/request-docs?requestId= — قائمة مستندات الطلب لموظفي المكتب (لحوار الاستكمال) */
export async function GET(req: NextRequest) {
  const session = await getUserSession();
  const requestId = req.nextUrl.searchParams.get("requestId") || "";
  if (!session?.officeId || !requestId) {
    return NextResponse.json({ documents: [] }, { status: 403 });
  }
  const docs = await db.requestDocument.findMany({
    where: { requestId, officeId: session.officeId },
    select: { name: true, status: true },
    distinct: ["name"],
  });
  return NextResponse.json({ documents: docs });
}
